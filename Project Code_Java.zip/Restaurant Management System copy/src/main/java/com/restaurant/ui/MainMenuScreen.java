package com.restaurant.ui;

import com.restaurant.model.MenuItem;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class MainMenuScreen {
    private final ObservableList<MenuItem> menuItems = FXCollections.observableArrayList();

    public MainMenuScreen() {
        menuItems.add(new MenuItem("Paneer Butter Masala", "Main Course", 180));
        menuItems.add(new MenuItem("Butter Naan", "Main Course", 25));
        menuItems.add(new MenuItem("Cold Coffee", "Drinks", 90));
        menuItems.add(new MenuItem("French Fries", "Snacks", 70));
    }
    public void show(Stage stage) {
        ListView<MenuItem> menuList = new ListView<>(menuItems);
        Button addItemButton = new Button("Add New Item");
        addItemButton.setOnAction(e -> new AddItemScreen(menuItems).show());
        VBox layout = new VBox(15, menuList, addItemButton);
        layout.setAlignment(Pos.CENTER);
        layout.setPadding(new Insets(20));
        Scene scene = new Scene(layout, 400, 500);
        stage.setTitle("Full Menu");
        stage.setScene(scene);
        stage.show();
    }
}
