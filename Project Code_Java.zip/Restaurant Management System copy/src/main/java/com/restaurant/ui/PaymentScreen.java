package com.restaurant.ui;

import com.restaurant.model.Order;
import com.restaurant.model.MenuItem;
import javafx.print.PrinterJob;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class PaymentScreen {

    public void show(Stage stage, Order order) {

        TextArea printArea = new TextArea();
        printArea.setEditable(false);

        StringBuilder bill = new StringBuilder("-------- Cafe SRM Bill --------\n\n");
        for (MenuItem item : order.getItems()) {
            bill.append(item.getName()).append("  ₹").append(item.getPrice()).append("\n");
        }
        bill.append("\nTotal: ₹").append(order.getTotal());
        bill.append("\n--------------------------------");

        printArea.setText(bill.toString());

        Button printBtn = new Button("Print Bill");
        printBtn.setOnAction(e -> {
            PrinterJob job = PrinterJob.createPrinterJob();
            if (job != null && job.printPage(printArea)) {
                job.endJob();
            }
        });

        VBox layout = new VBox(15, printArea, printBtn);
        layout.setAlignment(Pos.CENTER);
        layout.setStyle("-fx-padding: 20;");

        Scene scene = new Scene(layout, 400, 500);
        stage.setTitle("Payment & Print");
        stage.setScene(scene);
        stage.show();
    }
}
