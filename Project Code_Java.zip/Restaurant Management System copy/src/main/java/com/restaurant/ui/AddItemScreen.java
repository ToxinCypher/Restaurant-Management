package com.restaurant.ui;

import com.restaurant.model.MenuItem;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class AddItemScreen {

    private final ObservableList<MenuItem> menuItems;

    public AddItemScreen(ObservableList<MenuItem> menuItems) {
        this.menuItems = menuItems;
    }

    public void show() {
        Stage popup = new Stage();
        popup.initModality(Modality.APPLICATION_MODAL);
        popup.setTitle("Add New Menu Item");

        Label nameLabel = new Label("Item Name:");
        TextField nameField = new TextField();

        Label categoryLabel = new Label("Category:");
        TextField categoryField = new TextField();

        Label priceLabel = new Label("Price (₹):");
        TextField priceField = new TextField();

        Button saveButton = new Button("Save Item");
        saveButton.setOnAction(e -> {
            try {
                String name = nameField.getText();
                String category = categoryField.getText();
                double price = Double.parseDouble(priceField.getText());

                menuItems.add(new MenuItem(name, category, price));
                popup.close();

            } catch (Exception ex) {
                priceField.setStyle("-fx-border-color: red;");
            }
        });

        GridPane layout = new GridPane();
        layout.setVgap(12);
        layout.setHgap(12);
        layout.setPadding(new Insets(20));
        layout.setAlignment(Pos.CENTER);

        layout.addRow(0, nameLabel, nameField);
        layout.addRow(1, categoryLabel, categoryField);
        layout.addRow(2, priceLabel, priceField);
        layout.add(saveButton, 1, 3);

        Scene scene = new Scene(layout, 350, 230);
        popup.setScene(scene);
        popup.showAndWait();
    }
}
