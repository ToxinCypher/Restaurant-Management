package com.restaurant.controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.text.Text;

public class RestaurantController {
    @FXML
    private StackPane mainContent;
    private final ObservableList<MenuItem> menuItems = FXCollections.observableArrayList();
    private final ObservableList<String> orderItems = FXCollections.observableArrayList();
    private final String[] categories = {"Starters", "Main Course", "Desserts", "Drinks"};
    @FXML
    public void initialize() {
        menuItems.addAll(
                new MenuItem("Spring Rolls", "Starters", 120),
                new MenuItem("Paneer Butter Masala", "Main Course", 220),
                new MenuItem("Chocolate Brownie", "Desserts", 150),
                new MenuItem("Cold Coffee", "Drinks", 100)
        );
        showHome();
    }
    @FXML
    private void handleHome() {
        showHome();
    }
    @FXML
    private void handleMenu() {
        VBox menuBox = new VBox(20);
        menuBox.setStyle("-fx-padding: 20;");
        Label title = new Label("Cafe SRM Menu");
        title.setStyle("-fx-font-size: 22px; -fx-text-fill: #2c3e50;");
        for (String category : categories) {
            Label catLabel = new Label(category);
            catLabel.setStyle("-fx-font-size: 18px; -fx-text-fill: #2980b9; -fx-font-weight: bold;");
            VBox catBox = new VBox(10);
            for (MenuItem item : menuItems) {
                if (item.category.equals(category)) {
                    HBox itemRow = new HBox(10);
                    Label itemLabel = new Label(item.name + " - ₹" + item.price);
                    Button addBtn = new Button("Add to Order");
                    addBtn.setStyle("-fx-background-color: #27ae60; -fx-text-fill: white;");
                    addBtn.setOnAction(e -> orderItems.add(item.name + " - ₹" + item.price));
                    itemRow.getChildren().addAll(itemLabel, addBtn);
                    catBox.getChildren().add(itemRow);
                }
            }
            menuBox.getChildren().addAll(catLabel, catBox, new Separator());
        }
        mainContent.getChildren().setAll(menuBox);
    }
    @FXML
    private void handleAddMenuItem() {
        VBox addBox = new VBox(15);
        addBox.setStyle("-fx-padding: 20; -fx-alignment: center;");
        Label title = new Label("➕ Add New Menu Item");
        title.setStyle("-fx-font-size: 20px; -fx-text-fill: #2c3e50;");
        TextField nameField = new TextField();
        nameField.setPromptText("Item name");
        ComboBox<String> categoryBox = new ComboBox<>();
        categoryBox.getItems().addAll(categories);
        categoryBox.setPromptText("Select category");
        TextField priceField = new TextField();
        priceField.setPromptText("Price (₹)");
        Label msg = new Label();
        Button addBtn = new Button("Add Item");
        addBtn.setStyle("-fx-background-color: #27ae60; -fx-text-fill: white;");
        addBtn.setOnAction(e -> {
            String name = nameField.getText();
            String category = categoryBox.getValue();
            String priceText = priceField.getText();
            if (name.isEmpty() || category == null || priceText.isEmpty()) {
                msg.setText("Please fill all fields.");
                return;
            }
            try {
                double price = Double.parseDouble(priceText);
                menuItems.add(new MenuItem(name, category, price));
                msg.setText("Item added successfully!");
                nameField.clear();
                priceField.clear();
                categoryBox.setValue(null);
            } catch (NumberFormatException ex) {
                msg.setText("Invalid price!");
            }
        });
        addBox.getChildren().addAll(title, nameField, categoryBox, priceField, addBtn, msg);
        mainContent.getChildren().setAll(addBox);
    }
    @FXML
    private void handleRemoveMenuItem() {
        VBox removeBox = new VBox(15);
        removeBox.setStyle("-fx-padding: 20; -fx-alignment: center;");
        Label title = new Label("Remove Menu Item");
        title.setStyle("-fx-font-size: 20px; -fx-text-fill: #2c3e50;");
        ComboBox<String> itemBox = new ComboBox<>();
        for (MenuItem item : menuItems) {
            itemBox.getItems().add(item.name);
        }
        Label msg = new Label();
        Button removeBtn = new Button("Remove Item");
        removeBtn.setStyle("-fx-background-color: #e74c3c; -fx-text-fill: white;");
        removeBtn.setOnAction(e -> {
            String selected = itemBox.getValue();
            if (selected != null) {
                menuItems.removeIf(item -> item.name.equals(selected));
                itemBox.getItems().remove(selected);
                msg.setText(" "+selected + " removed from menu.");
            } else {
                msg.setText("Please select an item.");
            }
        });
        removeBox.getChildren().addAll(title, itemBox, removeBtn, msg);
        mainContent.getChildren().setAll(removeBox);
    }
    @FXML
    private void handleViewOrder() {
        VBox viewOrderBox = new VBox(15);
        viewOrderBox.setStyle("-fx-padding: 20; -fx-alignment: center;");
        Label title = new Label("Your Current Order");
        title.setStyle("-fx-font-size: 22px; -fx-text-fill: #2c3e50;");
        ListView<String> orderList = new ListView<>(orderItems);
        orderList.setPrefHeight(200);
        Label totalLabel = new Label();
        totalLabel.setStyle("-fx-font-size: 16px; -fx-text-fill: #16a085;");
        updateTotalPrice(totalLabel);
        orderItems.addListener((javafx.collections.ListChangeListener<String>) change -> updateTotalPrice(totalLabel));
        Button removeButton = new Button("Remove Selected");
        removeButton.setStyle("-fx-background-color: #e67e22; -fx-text-fill: white;");
        Button clearButton = new Button("Clear All");
        clearButton.setStyle("-fx-background-color: #e74c3c; -fx-text-fill: white;");
        Label infoLabel = new Label();
        removeButton.setOnAction(e -> {
            String selected = orderList.getSelectionModel().getSelectedItem();
            if (selected != null) {
                orderItems.remove(selected);
                infoLabel.setText("Removed " + selected);
            } else {
                infoLabel.setText("Please select an item to remove.");
            }
        });
        clearButton.setOnAction(e -> {
            if (!orderItems.isEmpty()) {
                orderItems.clear();
                infoLabel.setText("Order cleared!");
            } else {
                infoLabel.setText("No items to clear.");
            }
        });
        viewOrderBox.getChildren().addAll(title, orderList, totalLabel, removeButton, clearButton, infoLabel);
        mainContent.getChildren().setAll(viewOrderBox);
    }
    @FXML
    private void handleBilling() {
        VBox billingBox = new VBox(15);
        billingBox.setStyle("-fx-padding: 20; -fx-alignment: center;");

        Label title = new Label("Billing Summary");
        title.setStyle("-fx-font-size: 22px; -fx-text-fill: #2c3e50;");

        ListView<String> billList = new ListView<>(orderItems);
        billList.setPrefHeight(200);

        Label totalLabel = new Label();
        totalLabel.setStyle("-fx-font-size: 18px; -fx-text-fill: #27ae60;");
        updateTotalPrice(totalLabel);

        Button payBtn = new Button("Pay Now");
        payBtn.setStyle("-fx-background-color: #27ae60; -fx-text-fill: white;");
        payBtn.setOnAction(e -> {
            orderItems.clear();
            totalLabel.setText("Payment successful. Thank you!");
        });

        billingBox.getChildren().addAll(title, billList, totalLabel, payBtn);
        mainContent.getChildren().setAll(billingBox);
    }
    private void updateTotalPrice(Label label) {
        double total = 0;
        for (String item : orderItems) {
            try {
                int priceIndex = item.lastIndexOf("₹");
                if (priceIndex != -1) {
                    String priceStr = item.substring(priceIndex + 1).trim();
                    total += Double.parseDouble(priceStr);
                }
            } catch (Exception ignored) {}
        }
        label.setText("Total: ₹" + total);
    }
    private void showHome() {
        VBox homeBox = new VBox(15);
        homeBox.setStyle("-fx-padding: 20; -fx-alignment: center;");
        Label welcome = new Label("Welcome to Cafe SRM!");
        welcome.setStyle("-fx-font-size: 24px; -fx-text-fill: #2c3e50;");
        Text desc = new Text("Enjoy a cozy experience with delicious meals and desserts.");
        homeBox.getChildren().addAll(welcome, desc);
        mainContent.getChildren().setAll(homeBox);
    }
    public void handleAbout() {
        VBox aboutBox = new VBox(15);
        aboutBox.setStyle("-fx-padding: 20; -fx-alignment: center;");

        Label title = new Label("ℹ️ About Cafe SRM");
        title.setStyle("-fx-font-size: 22px; -fx-text-fill: #2c3e50;");

        Label desc = new Label("Cafe SRM is a cozy restaurant management system created to simplify menu and billing operations.Hope you enjoy!\n");
        desc.setStyle("-fx-font-size: 16px; -fx-text-fill: #34495e; -fx-text-alignment: center;");

        aboutBox.getChildren().addAll(title, desc);
        mainContent.getChildren().setAll(aboutBox);
    }
    static class MenuItem {
        String name;
        String category;
        double price;

        MenuItem(String name, String category, double price) {
            this.name = name;
            this.category = category;
            this.price = price;
        }
    }
}
