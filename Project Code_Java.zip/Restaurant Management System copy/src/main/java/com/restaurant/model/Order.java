package com.restaurant.model;

import java.util.ArrayList;
import java.util.List;

public class Order {
    private final List<MenuItem> items = new ArrayList<>();

    public void addItem(MenuItem item) { items.add(item); }
    public void removeItem(MenuItem item) { items.remove(item); }
    public List<MenuItem> getItems() { return items; }
    public double getTotal() { return items.stream().mapToDouble(MenuItem::getPrice).sum(); }
}
