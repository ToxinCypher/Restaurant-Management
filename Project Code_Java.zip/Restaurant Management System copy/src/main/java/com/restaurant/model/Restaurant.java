package com.restaurant.model;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class Restaurant {
    private final List<MenuItem> menu = new ArrayList<>();

    public void addMenuItem(MenuItem m) { menu.add(m); }

    public List<String> getCategories() {
        return menu.stream().map(MenuItem::getCategory).distinct().collect(Collectors.toList());
    }

    public List<MenuItem> getItemsByCategory(String category) {
        return menu.stream().filter(i -> i.getCategory().equals(category)).collect(Collectors.toList());
    }
}
