package com.restaurant.model;

public class OrderEntry {
    private final String name;
    private final double price;
    private int quantity;

    public OrderEntry(String name, double price) {
        this.name = name;
        this.price = price;
        this.quantity = 1;
    }

    public String getName() { return name; }
    public double getPrice() { return price; }

    public int getQuantity() { return quantity; }
    public void setQuantity(int quantity) { this.quantity = quantity; }

    public double getTotal() { return price * quantity; }

    public void inc() { quantity++; }
    public void dec() { if (quantity > 1) quantity--; }
}
